def get_random_number():
    import random
    return random.randint(1, 100)

def get_random_list():
    import random
    return [get_random_number() for _ in range(10)]

print("This module contains functions to generate random numbers.")